package pages;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;

import utility.SyncronizationClass;

public class ProductPage {
	
	WebDriver d;
	ExtentTest logger;
	SyncronizationClass sc;
	
	public ProductPage(WebDriver d, ExtentTest logger)
	{
		sc=new SyncronizationClass(d);
		
		this.logger=logger;
		this.d=d;
		
		PageFactory.initElements(d, this);
	}
	
	@FindBy (id="react-burger-menu-btn") public WebElement menuButton;
	@FindBy (xpath="//button[text()='Add to cart']") public WebElement addToCartButton;
	@FindBy (xpath="//button[text()='Remove']") public WebElement removeButton;
	@FindBy (xpath="//span[@class='shopping_cart_badge']") public WebElement productCountInCart;
	@FindBy (xpath="//a[@class='shopping_cart_link']") public WebElement cartIcon;
	@FindBy (xpath="//div[@class='app_logo']")  public WebElement Logo;
	
	@FindBy (xpath="//a[@class='bm-item menu-item']") public WebElement menuOption;
	@FindBy (xpath="//a[@class='bm-item menu-item']") public List<WebElement> menuOptionList;
	@FindBy (linkText="All Items") public WebElement allItemsOption;
	@FindBy (linkText="About") public WebElement aboutOption;
	@FindBy (linkText="Logout") public WebElement logoutOption;
	@FindBy (linkText="Reset App State") public WebElement resetApStateOption;
	@FindBy (id="react-burger-cross-btn") public WebElement CloseMenuButton;
	@FindBy (xpath="//select[@class='product_sort_container']") public WebElement filterDD;
	@FindBy (xpath="//div[@class='inventory_item_name']") public WebElement firstproductName;
	@FindBy (xpath="//div[@class='inventory_item_price']") public WebElement firstProductPrice;
	@FindBy (xpath="//div[@class='inventory_item_price']") public List<WebElement> productPriceList;
	@FindBy (xpath="//img[@class='inventory_item_img']") public List<WebElement> imagesList;
	@FindBy (xpath="//div[@class='inventory_item_name']") public List<WebElement> productNameList;
	@FindBy (xpath="//div[@class='inventory_item_desc']") public List<WebElement> productDescriptionList;

	
	public void clickOnRemoveButton()
	{
		sc.waitUntilElementDisplay(removeButton);
		
		removeButton.click();
		logger.createNode("clicked on Remove button on product page.");
	}
	
	public double getHighestPriceOFproducts()
	{
		sc.waitUntilElementIsClickabe(firstProductPrice);
		
		List<Double> PriceListInDouble=new ArrayList<Double>();
		
				for(WebElement e :productPriceList )
				{
					String priceOfProductWith$InString=e.getText();
					
					String priceOfProductWithout$InString=priceOfProductWith$InString.substring(1);
					
					double ProductPriceInDouble=Double.parseDouble(priceOfProductWithout$InString);
					
					PriceListInDouble.add(ProductPriceInDouble);
				}
				
				Collections.sort(PriceListInDouble); 
				
				for(double s: PriceListInDouble)
				{
					System.out.println(s);
				}	
		
		return PriceListInDouble.get(PriceListInDouble.size()-1);
	}
	
	public double getLowestPriceOFproducts()
	{
		sc.waitUntilElementIsClickabe(firstProductPrice);
		
		List<Double> PriceListInDouble=new ArrayList<Double>();
		
				for(WebElement e :productPriceList )
				{
					String priceOfProductWith$InString=e.getText();
					
					String priceOfProductWithout$InString=priceOfProductWith$InString.substring(1);
					
					double ProductPriceInDouble=Double.parseDouble(priceOfProductWithout$InString);
					
					PriceListInDouble.add(ProductPriceInDouble);
				}
				
				Collections.sort(PriceListInDouble); 
				
				for(double s: PriceListInDouble)
				{
					System.out.println(s);
				}	
		
		return PriceListInDouble.get(0);
	}
	
	
	public double getFirstProductPrice()
	{
		sc.waitUntilElementIsClickabe(firstProductPrice);
		String priceOfFirstProductWith$InString=firstProductPrice.getText();
		
		String priceOfFirstProductWithout$InString=priceOfFirstProductWith$InString.substring(1);
		
		double firstProductPriceInDouble=Double.parseDouble(priceOfFirstProductWithout$InString);
		return firstProductPriceInDouble;
	}
	
	public String getFirstProductName()
	{
		sc.waitUntilElementIsClickabe(firstproductName);
		
		return firstproductName.getText();
	}
	
	public void selectOptionFromFilterDD(String filterOption)
	{
		sc.waitUntilElementIsClickabe(filterDD);
		
		Select fdd=new Select(filterDD);
		
		fdd.selectByVisibleText(filterOption);
	
		logger.createNode("Selected option from filter Drop down list is "+filterOption);
	}
	
	public void clickOnCloseMenuButton()
	{
		sc.waitUntilElementIsClickabe(CloseMenuButton);
		CloseMenuButton.click();
		logger.createNode("Clicked on Close Menu Button.");
	}
	
	public void clickOnResetAppStateOption()
	{
		sc.waitUntilElementIsClickabe(resetApStateOption);
		resetApStateOption.click();
		logger.createNode("Clicked on Reset App State Option Button.");
	}
	
	public void clickOnLogoutOption()
	{
		sc.waitUntilElementIsClickabe(logoutOption);
		logoutOption.click();
		logger.createNode("Clicked on Logout Option Button.");
	}
	
	public void clickOnAboutOption()
	{
		sc.waitUntilElementIsClickabe(aboutOption);
		aboutOption.click();
		logger.createNode("Clicked on About Option Button.");
	}
	
	public void clickOnAllItemsOption()
	{
		sc.waitUntilElementIsClickabe(allItemsOption);
		allItemsOption.click();
		logger.createNode("Clicked on AllItemsOption Button.");
	}
	
	public void clickOnMenuButton()
	{
		sc.waitUntilElementIsClickabe(menuButton);
		menuButton.click();
		logger.createNode("Clicked on Menu Button.");
	}
	
	public void clickOnAddToCartButton()
	{
		sc.waitUntilElementIsClickabe(addToCartButton);
		addToCartButton.click();
		logger.createNode("Clicked on 'Add To Cart' Button.");
	}
	
	public void clickOnCartIcon()
	{
		sc.waitUntilElementIsClickabe(cartIcon);
		cartIcon.click();
		logger.createNode("Clicked on Cart Icon.");
	}
	
	public String getProductCountInCart()
	{
		sc.waitUntilElementDisplay(productCountInCart);
		logger.createNode("products present in the Cart is "+productCountInCart.getText());
		
		return productCountInCart.getText();
	}
}
