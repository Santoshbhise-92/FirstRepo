package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import utility.SyncronizationClass;

public class YourCartPage {
WebDriver d;
ExtentTest logger;
SyncronizationClass sc;
	
	public YourCartPage(WebDriver d,ExtentTest logger)
	{
		sc=new SyncronizationClass(d);
		
		this.d=d;
		this.logger=logger;
		
		PageFactory.initElements(d, this);
	}
	
	@FindBy (xpath="//button[text()='Remove']") public WebElement removeButton;
	@FindBy (id="react-burger-menu-btn") public WebElement menuButton;
	@FindBy (linkText="LinkedIn") public WebElement linkedInLink;
	
	@FindBy (xpath="//span[@class='shopping_cart_badge']") public WebElement productCountInCart;
	
	public void clickOnLinkedInLink()
	{
		sc.waitUntilElementDisplay(linkedInLink);
		
		linkedInLink.click();
		logger.createNode("Clicked on LinkedIn link on Your Cart page.");
	}
	
	public void clickOnRemoveButtonn()
	{
		sc.waitUntilElementDisplay(removeButton);
		
		removeButton.click();
		logger.createNode("Clicked on Remove button on Your Cart page.");
	}
	
	public String getProductCountInCart()
	{
		sc.waitUntilElementDisplay(productCountInCart);
		logger.createNode("products present in the Cart is "+productCountInCart.getText());
		
		return productCountInCart.getText();
	}
}
