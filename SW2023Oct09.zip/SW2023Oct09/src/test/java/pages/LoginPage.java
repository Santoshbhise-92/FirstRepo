package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import utility.SyncronizationClass;

public class LoginPage 
{
	
	WebDriver d;
	ExtentTest logger;
	 SyncronizationClass sc;
	
	public LoginPage(WebDriver d, ExtentTest logger)
	{
		sc=new SyncronizationClass(d);
		this.logger=logger;
		
		this.d=d;
		PageFactory.initElements(d, this);
	}
	
	
	//public WebElement userText = d.findElement(By.id("user-name"));
	
	@FindBy (xpath="//div[@class='login_logo']") public WebElement Logo;
	@FindBy (id="user-name") public WebElement userText;
	@FindBy (name="password") public WebElement passText;
	@FindBy (xpath="//input[@id='login-button']") public WebElement loginButton;
	
	
	public void enterUsername(String user)
	{
		sc.waitUntilElementDisplay(userText);
		
		userText.clear();
		userText.sendKeys(user);
		
		logger.createNode("Username Entered.");
	}
	
	public void enterPassword(String pass)
	{
		
		sc.waitUntilElementDisplay(passText);
		
		passText.clear();
		passText.sendKeys(pass);
		
		logger.createNode("Password Entered.");
	}
	
	public void clickOnLoginButton()
	{
		sc.waitUntilElementDisplay(loginButton);
		
		loginButton.click();
		logger.createNode("Clicked on Login Button.");
	}

}
