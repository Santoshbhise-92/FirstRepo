package learnCode;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddToCartScript {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver d=new ChromeDriver();
	d.manage().window().maximize();
	
	d.get("https://www.saucedemo.com/");
	
	d.findElement(By.id("user-name")).sendKeys("standard_user");
	
	d.findElement(By.name("password")).sendKeys("secret_sauce");
	
	d.findElement(By.xpath("//input[@id='login-button']")).click();
	
	d.findElement(By.xpath("//button[text()='Add to cart']")).click();
	
	Thread.sleep(3000);
	d.close();}

}
