package learnCode;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReaddataFromPropertyFile {

	public static void main(String[] args) throws IOException 
	{

		  Properties  prop=new Properties();  
		  
		  FileReader reader=new FileReader(System.getProperty("user.dir")+"/InputData/TestData.properties");  
		  
		  prop.load(reader); 
	 
	        System.out.println(prop.getProperty("URL"));  
	        System.out.println(prop.getProperty("Password"));  

	}

}
