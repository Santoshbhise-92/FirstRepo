package suite;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;
import pages.YourCartPage;



public class AS_30_VerifyMenuButtonOnYourCartPage extends Common
{

	@Test
	public void addToCartScript() 
	{
		logger = extent.createTest("To verify Menu button on Your Cart page.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
       YourCartPage  objYourCartPage=new  YourCartPage(d,logger);
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");
        
    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnCartIcon();
		
	
	Assert.assertTrue(objYourCartPage.menuButton.isDisplayed());
	  logger.createNode("Menu button displayed on your cart page.");
	}

}
