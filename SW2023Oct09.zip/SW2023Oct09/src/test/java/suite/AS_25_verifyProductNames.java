package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;


public class AS_25_verifyProductNames extends Common
{

	@Test
	public void verifyProductNames() 
	{
		logger = extent.createTest("To verify Products Names on product page.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
		
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");

    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
	Assert.assertEquals(objProductPage.productNameList.size(), 6);
	
	logger.createNode("Number of products Name displayed on page are = "+objProductPage.productNameList.size());
	
	}

}
