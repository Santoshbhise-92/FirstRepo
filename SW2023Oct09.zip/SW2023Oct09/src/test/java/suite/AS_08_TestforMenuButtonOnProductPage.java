package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;

public class AS_08_TestforMenuButtonOnProductPage extends Common
{	
	@Test
	public void loginScript() 
	{
		logger = extent.createTest("To verify Menu Button on Product page.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		ProductPage objProductPage=new ProductPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		Assert.assertTrue(objProductPage.menuButton.isDisplayed());
		logger.createNode("Menu button displayed.");
	
	}

}
