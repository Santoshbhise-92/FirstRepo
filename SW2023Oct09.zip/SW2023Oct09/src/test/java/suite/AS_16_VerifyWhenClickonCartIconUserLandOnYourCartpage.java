package suite;

import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

public class AS_16_VerifyWhenClickonCartIconUserLandOnYourCartpage extends Common
{

	@Test 
	public void verifyCartIcon()
	{
		logger = extent.createTest("To verify When Click on Cart icon user Land on your cart page.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		ProductPage objProductPage=new ProductPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("Website Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnCartIcon();
		
		Assert.assertTrue(d.getPageSource().contains("Your Cart"));
		logger.createNode("User is on Your Cart page.");
	}
}
