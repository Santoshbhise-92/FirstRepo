package suite;

import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

public class AS_10_VerifyLandOnProductPageWhenClickedOnAllItemMenuOption extends Common
{

	@Test 
	public void verifyAllItemsMenuOption()
	{
		logger = extent.createTest("To verify ALl Item Menu Option.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		ProductPage objProductPage=new ProductPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnMenuButton();
		
		objProductPage.clickOnAllItemsOption();
		
	//	Assert.assertTrue(objProductPage.menuButton.isDisplayed());
		Assert.assertFalse(d.getPageSource().contains("All Items"));
		logger.createNode("Clicked on All items Option.");
	}
}
