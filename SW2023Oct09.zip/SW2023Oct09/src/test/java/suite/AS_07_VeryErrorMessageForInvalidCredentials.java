package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;

import org.openqa.selenium.By;

public class AS_07_VeryErrorMessageForInvalidCredentials extends Common
{	
	@Test
	public void loginScript() 
	{
		logger = extent.createTest("To verify Error message for invalid credentials.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
	
		objLoginPage.enterUsername("InvalidUsername");
		
		objLoginPage.enterPassword("InvalidPassword");
	
		objLoginPage.clickOnLoginButton();
		
		Assert.assertTrue(d.getPageSource().contains("Username and password do not match any user in this service"));
		logger.createNode("For invalid credentials Error message displayed.");
	
	}

}
