package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;


public class AS_27_verifyProductDescriptions extends Common
{

	@Test
	public void verifyProductDescriptions() 
	{
		logger = extent.createTest("To verify Products Descriptions on product page.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
		
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");

    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
	Assert.assertEquals(objProductPage.productDescriptionList.size(), 6);
	
	logger.createNode("Number of product descriptions displayed on Product page are = "+objProductPage.productDescriptionList.size());
	
	}

}
