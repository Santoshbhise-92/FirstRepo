package suite;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.Common;
import pages.LoginPage;

public class AS_04_TestForEmptyPasswordError extends Common
{
	
	@Test 
    public void checkEmptyPasswordError()
    {
		logger=extent.createTest("To verify Empty Password Error message script.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
		
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.clickOnLoginButton();
		
		Assert.assertTrue(d.getPageSource().contains("Password is required"));
		logger.createNode("Empty Password Error message displayed.");
    }

}
