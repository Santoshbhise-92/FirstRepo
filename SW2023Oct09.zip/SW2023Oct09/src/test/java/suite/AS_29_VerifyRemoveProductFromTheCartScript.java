package suite;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;



public class AS_29_VerifyRemoveProductFromTheCartScript extends Common
{

	@Test
	public void addToCartScript() 
	{
		logger = extent.createTest("To verify Add to Cart Script.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
		
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");
        
    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnAddToCartButton();
		objProductPage.clickOnAddToCartButton();
		objProductPage.clickOnAddToCartButton();
		objProductPage.clickOnAddToCartButton();
		
		objProductPage.clickOnRemoveButton();
	
	Assert.assertEquals(objProductPage.getProductCountInCart(), "3");
	
	}

}
