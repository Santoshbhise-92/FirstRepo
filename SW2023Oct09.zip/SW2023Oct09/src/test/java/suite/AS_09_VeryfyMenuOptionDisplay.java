package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;

public class AS_09_VeryfyMenuOptionDisplay extends Common
{	
	@Test
	public void loginScript() 
	{
		logger = extent.createTest("To verify Menu Option dipsay on Product page.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		ProductPage objProductPage=new ProductPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnMenuButton();
		
		Assert.assertEquals(objProductPage.menuOptionList.size(), 4);
		logger.createNode("Menu option displayed. "+objProductPage.menuOptionList.size());
	
	}

}
