package suite;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;
import pages.YourCartPage;
import utility.UtilityClass;



public class AS_43_VerifyLinkedInLinkOnYourCartPage extends Common
{

	@Test
	public void addToCartScript() throws InterruptedException 
	{
		logger = extent.createTest("To verify Menu button on Your Cart page.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
       YourCartPage  objYourCartPage=new  YourCartPage(d,logger);
       UtilityClass  objUtilityClass=new UtilityClass(d,logger);
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");
        
    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnCartIcon();
		
		objYourCartPage.clickOnLinkedInLink();
		
		objUtilityClass.switchTowindow(1);
	
	Assert.assertTrue(d.getCurrentUrl().contains("linkedin.com"));
	 logger.createNode("LinkedIn wesite opned in the second window successfuly.");
	}

}
