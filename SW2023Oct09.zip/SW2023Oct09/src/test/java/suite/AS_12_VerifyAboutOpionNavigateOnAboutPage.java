package suite;

import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

public class AS_12_VerifyAboutOpionNavigateOnAboutPage extends Common
{

	@Test 
	public void verifyAboutMenuOption()
	{
		logger = extent.createTest("To verify Abput Menu Option.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		ProductPage objProductPage=new ProductPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnMenuButton();
		
		objProductPage.clickOnAboutOption();
		
     Assert.assertEquals(d.getCurrentUrl(), "https://saucelabs.com/");		
		logger.createNode("User is on About page.");
	}
}
