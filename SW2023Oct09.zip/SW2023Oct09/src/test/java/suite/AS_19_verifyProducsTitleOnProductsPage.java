package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;


public class AS_19_verifyProducsTitleOnProductsPage extends Common
{

	@Test
	public void verifyProductTitle() 
	{
		logger = extent.createTest("To verify Products title on product page Script.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
		
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");

    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
	
	Assert.assertTrue(d.getPageSource().contains("Products"));
	logger.createNode("Products title is present.");

	
		
	}

}
