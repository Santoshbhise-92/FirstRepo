package suite;

import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;

public class AS_02_TestForEmptyUsernameErrorMessage extends Common
{
	
	@Test 
	public void verifyEmptyUsernameError()
	{
		logger=extent.createTest("To verify Empty Username Error message script.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
		
		objLoginPage.clickOnLoginButton();
		
		Assert.assertTrue(d.getPageSource().contains("Username is required"));
		logger.createNode("Empty Username Error message displayed.");
		
	}

}
