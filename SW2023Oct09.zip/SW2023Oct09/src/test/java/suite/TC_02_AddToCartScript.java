package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;


public class TC_02_AddToCartScript extends Common
{

	@Test
	public void addToCartScript() 
	{
		logger = extent.createTest("To verify Add to Cart Script.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
		
       
        d.get(prop.getProperty("URL"));
   	
    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnAddToCartButton();
		objProductPage.clickOnAddToCartButton();
	
	AssertJUnit.assertEquals(objProductPage.getProductCountInCart(), "2");
		
	}

}
