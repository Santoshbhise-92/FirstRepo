package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;


public class AS_22_verifyFilterLowToHigh extends Common
{

	@Test
	public void verifyProductTitle() 
	{
		logger = extent.createTest("To verify Products Filter Low to High  Script.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
		
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");

    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
		double lowestPrice=objProductPage.getLowestPriceOFproducts();
		
		objProductPage.selectOptionFromFilterDD("Price (low to high)");
		
		double FirstProductPriceAfterFilterApply=objProductPage.getFirstProductPrice();
		
	Assert.assertEquals(FirstProductPriceAfterFilterApply, lowestPrice);
	
	logger.createNode("Low to High Filter applied and lowest price is = "+lowestPrice);
	
	}

}
