package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;

import org.openqa.selenium.By;

public class TC_01_LoginScript extends Common
{	
	@Test
	public void loginScript() 
	{
		logger = extent.createTest("To verify Login Script.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		
		
	 //   d.get("https://www.saucedemo.com/");	
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
		
	//	d.findElement(By.id("user-name")).sendKeys("standard_user");
		
	//	objLoginPage.userText.sendKeys("standard_user");
		
	//	objLoginPage.enterUsername("standard_user");
		
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		Assert.assertEquals(d.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
	
	}

}
