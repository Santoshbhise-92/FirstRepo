package suite;

import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;

public class AS_01_TestForLoginPageLogo extends Common

{ 

@Test 
public void verifyLogo()
{
	logger=extent.createTest("To verify Login page Logo script.");
	
	d.get(prop.getProperty("URL"));
	logger.createNode("WebSite Open successfully.");
	
	LoginPage objLoginPage=new LoginPage(d,logger);
	
	Assert.assertTrue(objLoginPage.Logo.isDisplayed());
	logger.createNode("Logo Displayed.");
}
}
