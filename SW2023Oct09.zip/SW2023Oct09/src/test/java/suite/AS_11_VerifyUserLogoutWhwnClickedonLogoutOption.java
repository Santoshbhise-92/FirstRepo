package suite;

import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

public class AS_11_VerifyUserLogoutWhwnClickedonLogoutOption extends Common
{

	@Test 
	public void verifyLogoutMenuOption()
	{
		logger = extent.createTest("To verify Logout Menu Option.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		ProductPage objProductPage=new ProductPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		objProductPage.clickOnMenuButton();
		
		objProductPage.clickOnLogoutOption();
		
		Assert.assertTrue(objLoginPage.loginButton.isDisplayed());
		
		logger.createNode("User Logged out successfully.");
	}
}
