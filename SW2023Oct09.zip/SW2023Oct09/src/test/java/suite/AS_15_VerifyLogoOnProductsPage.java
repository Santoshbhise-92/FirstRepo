package suite;

import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

public class AS_15_VerifyLogoOnProductsPage extends Common
{

	@Test 
	public void verifyResetAppStateMenuOption()
	{
		logger = extent.createTest("To verify close button closes Menu Options.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		ProductPage objProductPage=new ProductPage(d,logger);
		
		d.get(prop.getProperty("URL"));
		logger.createNode("Website Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		Assert.assertTrue(objProductPage.Logo.isDisplayed());
		logger.createNode("Logo displayed on Products Page.");
	}
}
