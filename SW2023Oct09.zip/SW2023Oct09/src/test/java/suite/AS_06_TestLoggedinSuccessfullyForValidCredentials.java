package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;

import org.openqa.selenium.By;

public class AS_06_TestLoggedinSuccessfullyForValidCredentials extends Common
{	
	@Test
	public void loginScript() 
	{
		logger = extent.createTest("To verify logged in successfully for valid credentials.");
		
		LoginPage objLoginPage=new LoginPage(d,logger);
		
		
		d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
	
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
	
		objLoginPage.clickOnLoginButton();
		
		Assert.assertEquals(d.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
		logger.createNode("Logged in successfully.");
	
	}

}
