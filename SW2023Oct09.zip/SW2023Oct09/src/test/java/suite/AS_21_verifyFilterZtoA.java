package suite;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;

import org.openqa.selenium.By;


public class AS_21_verifyFilterZtoA extends Common
{

	@Test
	public void verifyProductTitle() 
	{
		logger = extent.createTest("To verify Products Filter Z to A Script.");
	
		LoginPage objLoginPage=new LoginPage(d,logger);
       ProductPage  objProductPage=new  ProductPage(d,logger);
		
       
        d.get(prop.getProperty("URL"));
        logger.createNode("Website Open successfully.");

    	objLoginPage.enterUsername(prop.getProperty("Usename"));
     	objLoginPage.enterPassword(prop.getProperty("Password"));
		objLoginPage.clickOnLoginButton();
		
		String FirstProductNameBeforeFilterApply=objProductPage.getFirstProductName();
		
		objProductPage.selectOptionFromFilterDD("Name (Z to A)");
		
		String FirstProductNameAfterFilterApply=objProductPage.getFirstProductName();
	
	Assert.assertNotEquals(FirstProductNameBeforeFilterApply, FirstProductNameAfterFilterApply);
	
	logger.createNode("Z to A Filter applied successfully.");
	
	}

}
