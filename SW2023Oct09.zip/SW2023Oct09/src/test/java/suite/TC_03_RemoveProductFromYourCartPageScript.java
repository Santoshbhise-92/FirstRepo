package suite;


import org.testng.Assert;
import org.testng.annotations.Test;

import base.Common;
import pages.LoginPage;
import pages.ProductPage;
import pages.YourCartPage;

public class TC_03_RemoveProductFromYourCartPageScript extends Common
{
	
	
    @Test
    public void removeProductFromyourCart()
    {
    	logger = extent.createTest("To verify Remove product from Cart.");
    	
    	LoginPage objLoginPage=new LoginPage(d,logger);
    	ProductPage objProductPage=new ProductPage(d,logger);
    	YourCartPage objYourCartPage=new YourCartPage(d, logger);
    	
    	d.get(prop.getProperty("URL"));
		logger.createNode("WebSite Open successfully.");
		
		objLoginPage.enterUsername(prop.getProperty("Usename"));
		logger.createNode("Username Entered");
		
		objLoginPage.enterPassword(prop.getProperty("Password"));
		logger.createNode("Password Entered");
		
		objLoginPage.clickOnLoginButton();
		logger.createNode("Clicked on Login Button.");
    	
    	objProductPage.clickOnAddToCartButton();
    	objProductPage.clickOnAddToCartButton();
    	objProductPage.clickOnCartIcon();
    	
    	objYourCartPage.clickOnRemoveButtonn();
    	
    	Assert.assertEquals(objYourCartPage.getProductCountInCart(), "1");
    	
     }
	

}
