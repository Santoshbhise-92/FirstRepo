package utility;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;

public class SyncronizationClass 
{
	WebDriver d;
	WebDriverWait wt;
	
	public SyncronizationClass(WebDriver d)
	{
		 wt=new WebDriverWait(d,Duration.ofSeconds(30));
		 
		this.d=d;
	}
	
	
	public void waitUntilElementDisplay(WebElement e)
	{
		wt.until(ExpectedConditions.visibilityOf(e));
	}
	
	public void waitUntilAlertDisplay()
	{
		
		wt.until(ExpectedConditions.alertIsPresent());
	}
	
	public void waitUntilElementIsClickabe(WebElement e)
	{
		
		wt.until(ExpectedConditions.elementToBeClickable(e));
	}
		

}
