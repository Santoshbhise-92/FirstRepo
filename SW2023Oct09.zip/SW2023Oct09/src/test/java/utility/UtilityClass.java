package utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

public class UtilityClass 
{
	WebDriver d;
	ExtentTest logger;
	SyncronizationClass sc;
	
	public UtilityClass(WebDriver d, ExtentTest logger)
	{
		sc=new SyncronizationClass(d);
		
		this.logger=logger;
		this.d=d;
		
		PageFactory.initElements(d, this);
	}
	
	
	public void switchTowindow(int windowIndex) throws InterruptedException
	{
      Set<String> handleSet=d.getWindowHandles(); 
	
	   List<String> hadleArrayList =new ArrayList<String>();

	
	    for (String s:handleSet)
	    {
		   hadleArrayList.add(s);
	     }
	  
	    d.switchTo().window(hadleArrayList.get(windowIndex));    
	    logger.createNode("Swicthed into the window "+(windowIndex+1));
	}

}
